package app.nexus.gamespace;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/**
 * Everything NEXUS draws on top of the game except the big panel:
 * three HUD cards, the crosshair, the little edge handle and the recording chip.
 * HUD + crosshair never take touches, so the game stays fully playable underneath.
 */
final class OverlayViews {

    private static final int ACCENT = 0xFFFF3B6B;
    private static final float WINDOW_ALPHA = 0.8f;   // Android 12+ only lets touches pass through overlays up to 80% opaque

    private final Context ctx;
    private final WindowManager wm;
    private final Runnable onEdgeTap;
    private final Runnable onRecTap;
    private final float dp;

    private LinearLayout left, center, right;
    private TextView cpuT, ramT, hzT, tempNetT, timeT, batT;
    private CrosshairView cross;
    private View edge;
    private TextView recChip;
    private boolean shown = false;
    private boolean hidden = false;

    // latest data, so a rebuild (rotation) can redraw immediately
    private JSONObject state = new JSONObject();
    private JSONObject tele = new JSONObject();
    private boolean recording = false;
    private long recStart = 0;

    OverlayViews(Context ctx, WindowManager wm, Runnable onEdgeTap, Runnable onRecTap) {
        this.ctx = ctx;
        this.wm = wm;
        this.onEdgeTap = onEdgeTap;
        this.onRecTap = onRecTap;
        this.dp = Resources.getSystem().getDisplayMetrics().density;
    }

    private int px(float v) { return Math.round(v * dp); }

    // ------------------------------------------------------------------ build

    void show() {
        if (shown) return;
        shown = true;
        build();
        applyHidden();
        positionAll();
        refresh();
    }

    void hide() {
        if (!shown) return;
        shown = false;
        remove(left); remove(center); remove(right); remove(cross); remove(edge); remove(recChip);
        left = center = right = null;
        cross = null;
        edge = null;
        recChip = null;
    }

    /** Call after rotation or any display change. */
    void rebuild() {
        if (!shown) return;
        hide();
        show();
    }

    private void remove(View v) {
        if (v == null) return;
        try { wm.removeViewImmediate(v); } catch (Exception ignored) { /* already gone */ }
    }

    private void build() {
        cpuT = label(); ramT = label();
        left = card(cpuT, ramT);
        hzT = bigLabel(); tempNetT = label();
        center = card(hzT, tempNetT);
        timeT = bigLabel(); batT = label();
        right = card(timeT, batT);

        cross = new CrosshairView(ctx);
        recChip = new TextView(ctx);
        recChip.setTextColor(Color.WHITE);
        recChip.setTextSize(12);
        recChip.setTypeface(Typeface.DEFAULT_BOLD);
        recChip.setPadding(px(12), px(6), px(12), px(6));
        recChip.setBackground(round(0xE6B91C3C, 0, 16));
        recChip.setText("● REC 00:00");
        recChip.setOnClickListener(v -> onRecTap.run());
        recChip.setVisibility(View.GONE);

        edge = new View(ctx);
        edge.setBackground(round(0xCC7B5CFF, 0, 6));
        edge.setOnTouchListener(new EdgeTouch());

        add(left, Gravity.TOP | Gravity.START, 0, 0, false);
        add(center, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0, false);
        add(right, Gravity.TOP | Gravity.END, 0, 0, false);
        add(cross, Gravity.CENTER, 0, 0, false);
        add(recChip, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, px(64), true);
        addSized(edge, Gravity.END | Gravity.CENTER_VERTICAL, 0, -px(70), px(14), px(88), true);
    }

    private void add(View v, int gravity, int x, int y, boolean touchable) {
        addSized(v, gravity, x, y, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, touchable);
    }

    private void addSized(View v, int gravity, int x, int y, int w, int h, boolean touchable) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        if (!touchable) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        lp.gravity = gravity;
        lp.x = x;
        lp.y = y;
        lp.alpha = WINDOW_ALPHA;
        try {
            wm.addView(v, lp);
        } catch (Exception ignored) {
            // overlay permission was revoked while running
        }
    }

    private void move(View v, int gravity, int x, int y) {
        if (v == null) return;
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) v.getLayoutParams();
            if (lp == null) return;
            lp.gravity = gravity;
            lp.x = x;
            lp.y = y;
            wm.updateViewLayout(v, lp);
        } catch (Exception ignored) {
            // view is not attached right now
        }
    }

    // ------------------------------------------------------------------ small view helpers

    private GradientDrawable round(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(px(radiusDp));
        if (stroke != 0) g.setStroke(px(1), stroke);
        return g;
    }

    private TextView label() {
        TextView t = new TextView(ctx);
        t.setTextColor(0xFFE8E8F0);
        t.setTextSize(11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setSingleLine(true);
        return t;
    }

    private TextView bigLabel() {
        TextView t = label();
        t.setTextSize(15);
        t.setTextColor(Color.WHITE);
        return t;
    }

    private LinearLayout card(View a, View b) {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(px(10), px(6), px(10), px(6));
        l.setBackground(round(0xE60F0F18, 0x33FFFFFF, 12));
        l.addView(a);
        l.addView(b);
        return l;
    }

    // ------------------------------------------------------------------ data in

    /** Settings JSON written by the web UI (toggles, hudShow, hudPos, crosshair, tempUnit). */
    void applyState(JSONObject s) {
        state = s == null ? new JSONObject() : s;
        positionAll();
        refresh();
    }

    void updateTelemetry(JSONObject t) {
        if (t != null) tele = t;
        refresh();
    }

    void setRecording(boolean on, long startMs) {
        recording = on;
        recStart = startMs;
        refresh();
    }

    /** Makes every overlay piece invisible (still there, just transparent), e.g. during a screenshot. */
    void setHidden(boolean hidden) {
        this.hidden = hidden;
        applyHidden();
    }

    private void applyHidden() {
        float a = hidden ? 0f : 1f;
        for (View v : new View[]{left, center, right, cross, edge, recChip}) {
            if (v != null) v.setAlpha(a);
        }
    }

    private void refresh() {
        if (!shown || left == null) return;
        JSONObject tg = state.optJSONObject("toggles");
        JSONObject sh = state.optJSONObject("hudShow");
        JSONObject ch = state.optJSONObject("crosshair");
        boolean realtime = tg == null || tg.optBoolean("realtime", true);
        boolean crossOn = tg != null && tg.optBoolean("crosshair", false);
        boolean fahrenheit = "F".equals(state.optString("tempUnit", "C"));

        boolean vCpu = flag(sh, "cpu"), vGpu = flag(sh, "gpu"), vFps = flag(sh, "fps"), vTemp = flag(sh, "temp");
        boolean vNet = flag(sh, "wifi"), vTime = flag(sh, "time"), vBat = flag(sh, "battery");

        // left card: CPU + RAM
        int cpu = tele.optInt("cpu", -1);
        cpuT.setText("CPU  " + (cpu < 0 ? "–" : cpu + "%"));
        ramT.setText("RAM  " + tele.optInt("ram", 0) + "%");
        cpuT.setVisibility(vCpu ? View.VISIBLE : View.GONE);
        ramT.setVisibility(vGpu ? View.VISIBLE : View.GONE);
        left.setVisibility(realtime && (vCpu || vGpu) ? View.VISIBLE : View.GONE);

        // center card: refresh rate + temperature + network
        hzT.setText(tele.optInt("hz", 60) + " Hz");
        double c = tele.optDouble("temp", 0);
        String temp = fahrenheit ? Math.round(c * 9 / 5 + 32) + "°F" : Math.round(c) + "°C";
        tempNetT.setText(temp + "  ·  " + netName(tele.optString("net", "wifi")));
        hzT.setVisibility(vFps ? View.VISIBLE : View.GONE);
        tempNetT.setVisibility(vTemp || vNet ? View.VISIBLE : View.GONE);
        center.setVisibility(realtime && (vFps || vTemp || vNet) ? View.VISIBLE : View.GONE);

        // right card: clock + battery
        timeT.setText(tele.optString("time", "--:--"));
        batT.setText((tele.optBoolean("charging") ? "⚡ " : "") + tele.optInt("battery", 0) + "%");
        timeT.setVisibility(vTime ? View.VISIBLE : View.GONE);
        batT.setVisibility(vBat ? View.VISIBLE : View.GONE);
        right.setVisibility(realtime && (vTime || vBat) ? View.VISIBLE : View.GONE);

        // crosshair
        cross.setVisibility(crossOn ? View.VISIBLE : View.GONE);
        if (ch != null) cross.configure(ch.optString("style", "cross"), ch.optInt("size", 100), ch.optInt("opacity", 90));

        // recording chip
        recChip.setVisibility(recording ? View.VISIBLE : View.GONE);
        if (recording) {
            long sec = Math.max(0, (System.currentTimeMillis() - recStart) / 1000);
            recChip.setText(String.format(java.util.Locale.US, "● REC %02d:%02d  ·  tap to stop", sec / 60, sec % 60));
        }
    }

    /** Positions (web values are in dp; + is right / down). Only called when settings change, not every second. */
    private void positionAll() {
        if (!shown || left == null) return;
        JSONObject pos = state.optJSONObject("hudPos");
        int margin = px(6);
        move(left, Gravity.TOP | Gravity.START, margin + off(pos, "l", "x"), Math.max(0, margin + off(pos, "l", "y")));
        move(center, Gravity.TOP | Gravity.CENTER_HORIZONTAL, off(pos, "c", "x"), Math.max(0, margin + off(pos, "c", "y")));
        move(right, Gravity.TOP | Gravity.END, margin - off(pos, "r", "x"), Math.max(0, margin + off(pos, "r", "y")));
    }

    private boolean flag(JSONObject o, String k) { return o == null || o.optBoolean(k, true); }

    private int off(JSONObject pos, String card, String axis) {
        if (pos == null) return 0;
        JSONObject p = pos.optJSONObject(card);
        return p == null ? 0 : px((float) p.optDouble(axis, 0));
    }

    private String netName(String n) {
        if ("mobile".equals(n)) return "Mobile";
        if ("offline".equals(n)) return "Offline";
        if ("other".equals(n)) return "Network";
        return "Wi-Fi";
    }

    // ------------------------------------------------------------------ edge handle: tap or swipe inwards

    private final class EdgeTouch implements View.OnTouchListener {
        private float downX, downY;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawX() - downX) > px(24)) {   // swipe towards the middle of the screen
                        onEdgeTap.run();
                        downX = Float.MAX_VALUE;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(e.getRawX() - downX) < px(10) && Math.abs(e.getRawY() - downY) < px(10)) onEdgeTap.run();
                    return true;
                default:
                    return true;
            }
        }
    }

    // ------------------------------------------------------------------ crosshair

    private final class CrosshairView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String style = "cross";
        private int size = 100;
        private int opacity = 90;

        CrosshairView(Context c) {
            super(c);
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        void configure(String st, int sz, int op) {
            if (!st.equals(style) || sz != size || op != opacity) {
                style = st;
                size = sz;
                opacity = op;
                requestLayout();
                invalidate();
            }
        }

        private float half() { return px(14) * Math.max(30, Math.min(300, size)) / 100f; }

        @Override
        protected void onMeasure(int w, int h) {
            int d = (int) Math.ceil(half() * 2 + px(6));
            setMeasuredDimension(d, d);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = half();
            p.setColor(ACCENT);
            p.setAlpha(Math.round(255 * Math.max(10, Math.min(100, opacity)) / 100f));
            p.setStrokeWidth(px(2));
            if ("dot".equals(style)) {
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, Math.max(px(2.5f), r * 0.22f), p);
            } else if ("circle".equals(style)) {
                p.setStyle(Paint.Style.STROKE);
                cv.drawCircle(cx, cy, r * 0.8f, p);
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, px(1.5f), p);
            } else {
                p.setStyle(Paint.Style.STROKE);
                float gap = r * 0.28f;
                cv.drawLine(cx - r, cy, cx - gap, cy, p);
                cv.drawLine(cx + gap, cy, cx + r, cy, p);
                cv.drawLine(cx, cy - r, cx, cy - gap, p);
                cv.drawLine(cx, cy + gap, cx, cy + r, p);
            }
        }
    }
}

package app.nexus.gamespace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Runs while a game is in front: draws the HUD / crosshair / edge handle and hosts the
 * floating panel (the same web UI, loaded with ?mode=overlay) in a full-screen overlay window.
 */
public class OverlayService extends Service implements Bridge.Host {

    static OverlayService instance;

    static final String ACTION_START = "app.nexus.gamespace.START";
    static final String ACTION_PANEL = "app.nexus.gamespace.PANEL";
    static final String ACTION_STOP = "app.nexus.gamespace.STOP";

    private static final String CHANNEL = "nexus_overlay";
    private static final int NOTIF_ID = 41;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private OverlayViews views;
    private PanelWebView panel;
    private WindowManager.LayoutParams panelLp;
    private boolean panelOpen = false;
    private boolean running = false;

    static void start(Context c) {
        Intent i = new Intent(c, OverlayService.class).setAction(ACTION_START);
        c.startForegroundService(i);
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        views = new OverlayViews(this, wm, this::openPanel, () -> CaptureService.toggleRecording(this));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopOverlay();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action) || !running) goForeground();   // must be called after every startForegroundService()
        if (!running) {
            if (!Perms.overlay(this)) {
                stopForeground(true);
                stopSelf();
                return START_NOT_STICKY;
            }
            running = true;
            views.show();
            views.applyState(parse(Prefs.getState(this)));
            syncRecording();
            main.post(tick);
        }
        if (ACTION_PANEL.equals(action)) openPanel();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (running) main.postDelayed(() -> { if (views != null) views.rebuild(); }, 150);
    }

    @Override
    public void onDestroy() {
        running = false;
        main.removeCallbacksAndMessages(null);
        removePanel();
        if (views != null) views.hide();
        Controls.restoreDnd(this);
        if (instance == this) instance = null;
        super.onDestroy();
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            if (!Perms.overlay(OverlayService.this)) {   // user revoked the permission
                stopOverlay();
                return;
            }
            views.updateTelemetry(Telemetry.read(OverlayService.this));
            views.setRecording(CaptureService.isRecording(), CaptureService.recStart());
            main.postDelayed(this, 1000);
        }
    };

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "NEXUS Game Mode", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getService(this, 1,
                new Intent(this, OverlayService.class).setAction(ACTION_PANEL),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Icon icon = Icon.createWithResource(this, R.drawable.ic_stat);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("NEXUS Game Mode is on")
                .setContentText("Swipe in from the right edge, or tap Open panel")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(icon, "Open panel", open).build())
                .addAction(new Notification.Action.Builder(icon, "Stop", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void stopOverlay() {
        running = false;
        main.removeCallbacksAndMessages(null);
        CaptureService.stopAll(this);
        stopForeground(true);
        stopSelf();
    }

    private static JSONObject parse(String json) {
        try {
            return json == null || json.isEmpty() ? new JSONObject() : new JSONObject(json);
        } catch (JSONException e) {
            return new JSONObject();
        }
    }

    // ------------------------------------------------------------------ called by Bridge / CaptureService

    /** Settings changed (from the panel or from the app screen). */
    void onStateChanged(final String json, final boolean fromPanel) {
        main.post(() -> {
            if (views != null) views.applyState(parse(json));
            if (!fromPanel && panel != null) js("window.__nativeState&&window.__nativeState(" + JSONObject.quote(json) + ")");
        });
    }

    /** Recording started / stopped. */
    static void recordingChanged() {
        final OverlayService s = instance;
        if (s != null) s.main.post(s::syncRecording);
    }

    /** Hide HUD / crosshair while a screenshot is taken. */
    static void hideHud(final boolean hide) {
        final OverlayService s = instance;
        if (s != null) s.main.post(() -> {
            if (s.views != null) s.views.setHidden(hide);
            if (hide) s.closePanelNow();
        });
    }

    private void syncRecording() {
        if (views != null) views.setRecording(CaptureService.isRecording(), CaptureService.recStart());
        if (panel != null) js("window.__refresh&&window.__refresh()");
    }

    // ------------------------------------------------------------------ Bridge.Host

    @Override
    public boolean launchGame(String pkg) {
        final Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) return false;
        main.post(() -> {
            try {
                closePanelNow();
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(launch);
            } catch (Exception ignored) {
                // could not start that app
            }
        });
        return true;
    }

    @Override
    public void closePanel() {
        main.post(this::closePanelNow);
    }

    @Override
    public void exitOverlay() {
        main.post(this::stopOverlay);
    }

    // ------------------------------------------------------------------ floating panel (web UI in an overlay window)

    private final class PanelWebView extends WebView {
        PanelWebView(Context c) { super(c); }

        @Override
        public boolean dispatchKeyEvent(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                if (e.getAction() == KeyEvent.ACTION_UP) {
                    evaluateJavascript("(window.__back&&window.__back())===true", v -> {
                        if (!"true".equals(v)) closePanelNow();
                    });
                }
                return true;
            }
            return super.dispatchKeyEvent(e);
        }
    }

    private void js(String code) {
        if (panel != null) panel.evaluateJavascript(code, null);
    }

    void openPanel() {
        main.post(() -> {
            if (!running || !Perms.overlay(this)) return;
            boolean first = panel == null;
            if (first) createPanel();
            if (panel == null) return;
            setPanelWindow(true);
            panel.onResume();
            panelOpen = true;
            if (!first) {
                js("window.__nativeState&&window.__nativeState(" + JSONObject.quote(Prefs.getState(this)) + ")");
                js("window.__nativeEvent&&window.__nativeEvent('{\"panelOpen\":true,\"subPanelOpen\":false,\"screen\":\"game\",\"game\":\"overlay\"}')");
                js("window.__refresh&&window.__refresh()");
            }
        });
    }

    private void createPanel() {
        panel = new PanelWebView(new ContextThemeWrapper(this, android.R.style.Theme_Material));
        panel.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = panel.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        panel.addJavascriptInterface(new Bridge(this, this), "NexusNative");
        panel.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        panelLp = new WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        try {
            wm.addView(panel, panelLp);
        } catch (Exception e) {
            panel = null;
            return;
        }
        panel.loadUrl("file:///android_asset/index.html?mode=overlay");
    }

    private void setPanelWindow(boolean open) {
        if (panel == null || panelLp == null) return;
        if (open) {
            panelLp.width = WindowManager.LayoutParams.MATCH_PARENT;
            panelLp.height = WindowManager.LayoutParams.MATCH_PARENT;
            panelLp.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
            panelLp.alpha = 1f;
        } else {
            panelLp.width = 1;
            panelLp.height = 1;
            panelLp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            panelLp.alpha = 0.8f;
        }
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Exception ignored) {
            // window already removed
        }
    }

    private void closePanelNow() {
        if (panel == null || !panelOpen) return;
        panelOpen = false;
        setPanelWindow(false);
        panel.onPause();
    }

    private void removePanel() {
        if (panel == null) return;
        try { wm.removeViewImmediate(panel); } catch (Exception ignored) { /* already gone */ }
        panel.removeJavascriptInterface("NexusNative");
        panel.destroy();
        panel = null;
    }
}

package app.nexus.gamespace;

import android.content.Context;
import android.os.Build;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

/**
 * The object the web UI sees as window.NexusNative.
 * NOTE: every method here runs on a background thread, never the UI thread.
 */
final class Bridge {

    /** Implemented by MainActivity (app screen) and OverlayService (panel over a game). */
    interface Host {
        boolean launchGame(String pkg);
        void closePanel();
        void exitOverlay();
    }

    private final Context c;
    private final Host host;

    Bridge(Context context, Host host) {
        this.c = context.getApplicationContext();
        this.host = host;
    }

    // ---------- saved settings ----------

    @JavascriptInterface
    public String getState() {
        return Prefs.getState(c);
    }

    @JavascriptInterface
    public void setState(String json) {
        if (json == null) return;
        Prefs.setState(c, json);
        OverlayService s = OverlayService.instance;
        if (s != null) s.onStateChanged(json, host == s);
        MainActivity m = MainActivity.instance;
        if (m != null && host != m) m.pushState(json);
    }

    /** Values that are not "settings" but the real current situation of the phone. */
    @JavascriptInterface
    public String getRuntime() {
        JSONObject o = new JSONObject();
        try {
            o.put("blockNotif", Controls.dndOn(c));
            o.put("brightness", Controls.getBrightness(c));
            o.put("volume", Controls.getVolume(c));
            o.put("recording", CaptureService.isRecording());
            o.put("recStart", CaptureService.recStart());
            o.put("perms", Perms.status(c));
        } catch (Exception ignored) {
            // keep what we have
        }
        return o.toString();
    }

    // ---------- apps ----------

    @JavascriptInterface
    public String getApps() {
        return Apps.listJson(c);
    }

    @JavascriptInterface
    public String getIcon(String pkg) {
        return Apps.icon(c, pkg);
    }

    @JavascriptInterface
    public boolean launchGame(String pkg) {
        if (pkg == null || host == null || !Perms.overlay(c)) return false;
        return host.launchGame(pkg);
    }

    // ---------- live numbers & permissions ----------

    @JavascriptInterface
    public String getTelemetry() {
        return Telemetry.read(c).toString();
    }

    @JavascriptInterface
    public String getPermissions() {
        return Perms.status(c).toString();
    }

    @JavascriptInterface
    public void requestPermission(String key) {
        MainActivity m = MainActivity.instance;
        if ("notifications".equals(key) && Build.VERSION.SDK_INT >= 33 && m != null) {
            m.askNotifications();
        } else {
            Perms.openSettings(c, key);
        }
    }

    // ---------- things the panel can do ----------

    @JavascriptInterface
    public boolean setBrightness(int percent) {
        return Controls.setBrightness(c, percent);
    }

    @JavascriptInterface
    public void setVolume(int percent) {
        Controls.setVolume(c, percent);
    }

    @JavascriptInterface
    public boolean setBlockNotifications(boolean on) {
        return Controls.setDnd(c, on);
    }

    @JavascriptInterface
    public void capture() {
        CaptureService.screenshot(c);
    }

    @JavascriptInterface
    public void toggleRecording() {
        CaptureService.toggleRecording(c);
    }

    @JavascriptInterface
    public void closePanel() {
        if (host != null) host.closePanel();
    }

    @JavascriptInterface
    public void exitOverlay() {
        if (host != null) host.exitOverlay();
    }
}

package app.nexus.gamespace;

import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.media.AudioManager;
import android.provider.Settings;

/** System switches the panel can change: brightness, media volume, Do Not Disturb. */
final class Controls {
    private Controls() { }

    // ---- brightness (needs the "Modify system settings" permission) ----

    static boolean setBrightness(Context c, int percent) {
        if (!Settings.System.canWrite(c)) return false;
        try {
            int v = Math.max(1, Math.min(255, Math.round(percent * 255f / 100f)));
            ContentResolver r = c.getContentResolver();
            Settings.System.putInt(r, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(r, Settings.System.SCREEN_BRIGHTNESS, v);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static int getBrightness(Context c) {
        try {
            int v = Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
            return Math.max(1, Math.min(100, Math.round(v * 100f / 255f)));
        } catch (Exception e) {
            return 50;
        }
    }

    // ---- media volume (no permission needed) ----

    static void setVolume(Context c, int percent) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            int v = Math.max(0, Math.min(max, Math.round(percent * max / 100f)));
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
        } catch (Exception ignored) {
            // some phones block this while a call is active
        }
    }

    static int getVolume(Context c) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            return max <= 0 ? 50 : Math.round(100f * am.getStreamVolume(AudioManager.STREAM_MUSIC) / max);
        } catch (Exception e) {
            return 50;
        }
    }

    // ---- Do Not Disturb = "Block Notifications" (needs Do Not Disturb access) ----

    /** True only while NEXUS itself switched Do Not Disturb on and it is still on. */
    static boolean dndOn(Context c) {
        if (!Prefs.getBool(c, "dndOn", false) || !Perms.dnd(c)) return false;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
    }

    static boolean setDnd(Context c, boolean on) {
        if (!Perms.dnd(c)) return false;
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (on) {
                if (!Prefs.getBool(c, "dndOn", false)) {
                    Prefs.putInt(c, "dndPrev", nm.getCurrentInterruptionFilter());
                    Prefs.putBool(c, "dndOn", true);
                }
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            } else {
                restoreDnd(c);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Puts Do Not Disturb back the way it was before NEXUS changed it. */
    static void restoreDnd(Context c) {
        try {
            if (!Prefs.getBool(c, "dndOn", false)) return;
            Prefs.putBool(c, "dndOn", false);
            if (!Perms.dnd(c)) return;
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            int prev = Prefs.getInt(c, "dndPrev", NotificationManager.INTERRUPTION_FILTER_ALL);
            if (prev == NotificationManager.INTERRUPTION_FILTER_UNKNOWN) prev = NotificationManager.INTERRUPTION_FILTER_ALL;
            nm.setInterruptionFilter(prev);
        } catch (Exception ignored) {
            // nothing else we can do
        }
    }
}

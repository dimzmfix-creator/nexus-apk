package app.nexus.gamespace;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/**
 * Everything that needs Shizuku (shell-level access). Nothing here touches game files:
 * it only changes system settings and Android's own Game Mode, and puts them back afterwards.
 */
final class Sx {

    static final String PKG = "moe.shizuku.privileged.api";
    private static final String PREV = "sxPrev";

    private Sx() {}

    static boolean installed(Context c) {
        try {
            c.getPackageManager().getPackageInfo(PKG, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean running() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean granted() {
        try {
            return running() && !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    static void request() {
        try {
            if (running() && !Shizuku.isPreV11()) Shizuku.requestPermission(7301);
        } catch (Throwable ignored) {
            // Shizuku not usable right now
        }
    }

    static String status(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("installed", installed(c));
            o.put("running", running());
            o.put("granted", granted());
        } catch (Exception ignored) {
            // keep what we have
        }
        return o.toString();
    }

    static boolean openApp(Context c) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(PKG);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
        return true;
    }

    /** Runs one shell command through Shizuku. Returns its output, or null if it could not run. */
    static String sh(String cmd) {
        if (!granted()) return null;
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new String[]{"sh", "-c", cmd + " 2>&1"}, null, null);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            p.waitFor();
            return sb.toString().trim();
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean bad(String out) {
        return out == null || out.contains("Exception") || out.contains("Unknown command")
                || out.contains("Error") || out.contains("not found") || out.contains("Permission denied");
    }

    private static String pkgSafe(String s) {
        return s != null && s.matches("[A-Za-z0-9._]+") ? s : null;
    }

    private static String get(String ns, String key) {
        String v = sh("settings get " + ns + " " + key);
        return v == null ? "null" : v;
    }

    private static void restore(String ns, String key, String v) {
        if (v == null || v.equals("null") || v.isEmpty()) sh("settings delete " + ns + " " + key);
        else sh("settings put " + ns + " " + key + " " + v);
    }

    /**
     * profile JSON: {hz, mode:'standar|performa|hemat', fps, res, lock, pixel}
     * Returns {ok, done:[...], failed:[...]} so the screen can say exactly what worked on this phone.
     */
    static String apply(Context c, String pkg, String json) {
        JSONObject out = new JSONObject();
        org.json.JSONArray done = new org.json.JSONArray(), failed = new org.json.JSONArray();
        try {
            pkg = pkgSafe(pkg);
            if (pkg == null || !granted()) {
                out.put("ok", false);
                return out.toString();
            }
            JSONObject p = new JSONObject(json == null ? "{}" : json);
            JSONObject prev = new JSONObject();
            prev.put("pkg", pkg);
            prev.put("minHz", get("system", "min_refresh_rate"));
            prev.put("peakHz", get("system", "peak_refresh_rate"));
            Prefs.putString(c, PREV, prev.toString());

            int hz = p.optInt("hz", 0);
            if (hz > 0) {
                String a = sh("settings put system min_refresh_rate " + hz);
                String b = sh("settings put system peak_refresh_rate " + hz);
                (bad(a) || bad(b) ? failed : done).put("hz");
            }
            if (p.optBoolean("lock", false)) {
                (bad(sh("cmd power set-fixed-performance-mode-enabled true")) ? failed : done).put("lock");
            }
            if (Build.VERSION.SDK_INT >= 33) {
                String mode = p.optString("mode", "standar");
                String m = "performa".equals(mode) ? "performance" : "hemat".equals(mode) ? "battery" : "standard";
                int fps = p.optInt("fps", 0), res = p.optInt("res", 100);
                if (p.optBoolean("pixel", false)) res = Math.min(res, 50);
                StringBuilder cmd = new StringBuilder("cmd game set --mode " + m);
                if (res > 0 && res < 100) cmd.append(" --downscale ").append(String.format(java.util.Locale.US, "%.2f", res / 100.0));
                if (fps > 0) cmd.append(" --fps ").append(fps);
                cmd.append(' ').append(pkg);
                (bad(sh(cmd.toString())) ? failed : done).put("game");
            } else {
                failed.put("game");
            }
            out.put("ok", true);
        } catch (Exception e) {
            // report what we have
        }
        try {
            out.put("done", done);
            out.put("failed", failed);
        } catch (Exception ignored) {
            // nothing more to add
        }
        return out.toString();
    }

    /** Puts back what apply() changed. Safe to call more than once. */
    static void revert(Context c) {
        String s = Prefs.getString(c, PREV, "");
        if (s.isEmpty() || !granted()) return;
        try {
            JSONObject prev = new JSONObject(s);
            restore("system", "min_refresh_rate", prev.optString("minHz"));
            restore("system", "peak_refresh_rate", prev.optString("peakHz"));
            sh("cmd power set-fixed-performance-mode-enabled false");
            String pkg = pkgSafe(prev.optString("pkg"));
            if (pkg != null && Build.VERSION.SDK_INT >= 33) sh("cmd game reset " + pkg);
        } catch (Exception ignored) {
            // nothing to restore
        }
        Prefs.putString(c, PREV, "");
    }

    /** mode: auto | off | host. Private DNS is a normal Android setting. */
    static boolean dns(String mode, String host) {
        if ("off".equals(mode)) return !bad(sh("settings put global private_dns_mode off"));
        if ("auto".equals(mode)) return !bad(sh("settings put global private_dns_mode opportunistic"));
        if (host == null || !host.matches("[A-Za-z0-9.-]+")) return false;
        String a = sh("settings put global private_dns_specifier " + host);
        String b = sh("settings put global private_dns_mode hostname");
        return !bad(a) && !bad(b);
    }

    static String dnsNow() {
        String m = sh("settings get global private_dns_mode");
        String h = sh("settings get global private_dns_specifier");
        JSONObject o = new JSONObject();
        try {
            o.put("mode", m == null ? "" : m);
            o.put("host", h == null || h.equals("null") ? "" : h);
        } catch (Exception ignored) {
            // keep what we have
        }
        return o.toString();
    }

    /** Frees RAM like Boost but deeper: kills cached background processes and trims app caches. */
    static String deepClean() {
        String a = sh("am kill-all");
        String b = sh("pm trim-caches 999G");
        JSONObject o = new JSONObject();
        try {
            o.put("kill", !bad(a));
            o.put("cache", !bad(b));
        } catch (Exception ignored) {
            // keep what we have
        }
        return o.toString();
    }

    /** kind: wifi | data */
    static boolean net(String kind, boolean on) {
        if (!"wifi".equals(kind) && !"data".equals(kind)) return false;
        return !bad(sh("svc " + kind + (on ? " enable" : " disable")));
    }
}

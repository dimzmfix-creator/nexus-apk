package app.nexus.gamespace;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

/** The normal NEXUS app screen: the web UI (assets/index.html) inside a WebView. */
public class MainActivity extends Activity implements Bridge.Host {

    static MainActivity instance;

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;

        web = new WebView(this);
        web.setBackgroundColor(0xFF0A0A0F);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setAllowFileAccess(false);          // file:///android_asset still works
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(this, this), "NexusNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        // ask once for notification permission (Android 13+), so the "overlay is running" notice is visible
        if (Build.VERSION.SDK_INT >= 33 && !Perms.notifications(this)
                && !Prefs.getBool(this, "askedNotif", false)) {
            Prefs.putBool(this, "askedNotif", true);
            askNotifications();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        js("window.__refresh&&window.__refresh()");   // user may just be back from a Settings page
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back&&window.__back())===true", v -> {
            if (!"true".equals(v)) moveTaskToBack(true);
        });
    }

    @Override
    protected void onDestroy() {
        if (instance == this) instance = null;
        if (web != null) {
            web.removeJavascriptInterface("NexusNative");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    // ---------- called from Bridge / OverlayService ----------

    void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            runOnUiThread(() -> requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1));
        }
    }


    /** "landscape" turns the screen sideways; anything else goes back to following the phone. */
    void applyOrientation(final String mode) {
        runOnUiThread(() -> setRequestedOrientation("landscape".equals(mode)
                ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
    }

    void pushSx(String json) {
        js("window.__sx&&window.__sx(" + JSONObject.quote(json) + ")");
    }

    /** Settings were changed in the floating panel: refresh this screen too. */
    void pushState(String json) {
        js("window.__nativeState&&window.__nativeState(" + JSONObject.quote(json) + ")");
    }

    private void js(final String code) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        js("window.__refresh&&window.__refresh()");
    }

    // ---------- Bridge.Host ----------

    @Override
    public boolean launchGame(String pkg) {
        final Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) return false;
        runOnUiThread(() -> {
            try {
                OverlayService.gamePkg = pkg;
                OverlayService.start(MainActivity.this);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(launch);
            } catch (Exception ignored) {
                // the game could not be started
            }
        });
        return true;
    }

    @Override
    public void closePanel() { /* only meaningful inside the overlay */ }

    @Override
    public void exitOverlay() { /* only meaningful inside the overlay */ }
}

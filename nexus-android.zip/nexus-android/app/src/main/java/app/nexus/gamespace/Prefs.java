package app.nexus.gamespace;

import android.content.Context;
import android.content.SharedPreferences;

/** Tiny wrapper around SharedPreferences. The whole web UI state is stored as one JSON string. */
final class Prefs {
    private Prefs() { }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("nexus", Context.MODE_PRIVATE);
    }

    static String getState(Context c) { return sp(c).getString("state", ""); }
    static void setState(Context c, String json) { sp(c).edit().putString("state", json).apply(); }

    static String getString(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putString(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    static int getInt(Context c, String k, int d) { return sp(c).getInt(k, d); }
    static void putInt(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }
    static boolean getBool(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    static void putBool(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
}

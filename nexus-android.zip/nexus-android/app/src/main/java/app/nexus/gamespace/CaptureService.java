package app.nexus.gamespace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Screenshot + screen recording through MediaProjection.
 * Android asks the user for permission once per session; after that the same projection is reused:
 * the (single) VirtualDisplay is simply pointed at an ImageReader for a screenshot,
 * or at a MediaRecorder for a clip, and at nothing when idle.
 * Files go to Pictures/NEXUS and Movies/NEXUS (MediaStore, no storage permission needed).
 */
public class CaptureService extends Service {

    private static final String ACTION_BEGIN = "app.nexus.gamespace.CAPTURE_BEGIN";
    private static final String ACTION_DO = "app.nexus.gamespace.CAPTURE_DO";
    private static final String ACTION_STOP_ALL = "app.nexus.gamespace.CAPTURE_STOP";
    private static final String CHANNEL = "nexus_capture";
    private static final int NOTIF_ID = 42;

    private static volatile CaptureService live;     // non-null while a projection is active
    private static volatile boolean recording = false;
    private static volatile long recStartMs = 0;

    // ------------------------------------------------------------------ public API (called from anywhere)

    static boolean isRecording() { return recording; }

    static long recStart() { return recStartMs; }

    static void screenshot(Context c) { request(c, "shot"); }

    /** Starts a clip, or stops the one that is running. */
    static void toggleRecording(Context c) { request(c, "rec"); }

    static void stopAll(Context c) {
        if (live == null && !recording) return;
        try {
            c.startService(new Intent(c, CaptureService.class).setAction(ACTION_STOP_ALL));
        } catch (Exception ignored) {
            // service is already gone
        }
    }

    /** Called by ProjectionActivity once the user said yes. */
    static void begin(Context c, int resultCode, Intent data, String what) {
        Intent i = new Intent(c, CaptureService.class).setAction(ACTION_BEGIN)
                .putExtra("code", resultCode).putExtra("data", data).putExtra("what", what);
        c.startForegroundService(i);
    }

    private static void request(Context c, String what) {
        try {
            if (live != null) {
                c.startService(new Intent(c, CaptureService.class).setAction(ACTION_DO).putExtra("what", what));
            } else {
                c.startActivity(new Intent(c, ProjectionActivity.class).putExtra("what", what)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        } catch (Exception e) {
            // e.g. overlay permission missing, nothing to do
        }
    }

    // ------------------------------------------------------------------ instance state

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread thread;
    private Handler bg;

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private MediaRecorder recorder;
    private ParcelFileDescriptor recPfd;
    private Uri recUri;
    private boolean closing = false;
    private boolean shotBusy = false;

    @Override
    public void onCreate() {
        super.onCreate();
        thread = new HandlerThread("nexus-capture");
        thread.start();
        bg = new Handler(thread.getLooper());
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACTION_BEGIN.equals(a)) {
            goForeground();
            try {
                MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                Intent data = intent.getParcelableExtra("data");
                projection = mpm.getMediaProjection(intent.getIntExtra("code", 0), data);
                projection.registerCallback(new MediaProjection.Callback() {
                    @Override
                    public void onStop() {
                        bg.post(() -> shutdown());   // user stopped sharing from the system status-bar chip
                    }
                }, bg);
                live = this;
            } catch (Exception e) {
                toast("Could not start screen capture");
                shutdown();
                return START_NOT_STICKY;
            }
            run(intent.getStringExtra("what"));
        } else if (ACTION_DO.equals(a)) {
            run(intent.getStringExtra("what"));
        } else if (ACTION_STOP_ALL.equals(a)) {
            bg.post(this::shutdown);
        } else {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        live = null;
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "NEXUS capture", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("NEXUS can capture your screen")
                .setContentText("Turns off when you exit Game Mode")
                .setOngoing(true)
                .build();
        startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
    }

    private void run(final String what) {
        if ("rec".equals(what)) {
            bg.post(() -> { if (recording) stopRecording(); else startRecording(); });
        } else {
            OverlayService.hideHud(true);                 // keep HUD / crosshair / panel out of the picture
            bg.postDelayed(this::takeScreenshot, 550);
        }
    }

    private void toast(final String msg) {
        main.post(() -> Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show());
    }

    // ------------------------------------------------------------------ display helpers

    @SuppressWarnings("deprecation")
    private int[] screenSize() {
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels, dm.densityDpi};
    }

    private void ensureDisplay(int w, int h, int dpi) {
        if (vd == null) {
            vd = projection.createVirtualDisplay("nexus-capture", w, h, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null);
        } else {
            vd.resize(w, h, dpi);
        }
    }

    // ------------------------------------------------------------------ screenshot

    private void takeScreenshot() {
        if (projection == null || closing) {
            OverlayService.hideHud(false);
            return;
        }
        if (shotBusy) return;
        shotBusy = true;
        try {
            int[] s = screenSize();
            final int w = s[0], h = s[1];
            ensureDisplay(w, h, s[2]);
            final ImageReader r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            reader = r;
            final boolean[] done = {false};
            r.setOnImageAvailableListener(rd -> {
                if (done[0]) return;
                Image img = null;
                try {
                    img = rd.acquireLatestImage();
                    if (img == null) return;
                    done[0] = true;
                    Bitmap bmp = toBitmap(img, w, h);
                    finishShot();
                    saveShot(bmp);
                } catch (Exception e) {
                    done[0] = true;
                    finishShot();
                    toast("Screenshot failed");
                } finally {
                    if (img != null) img.close();
                }
            }, bg);
            vd.setSurface(r.getSurface());
            bg.postDelayed(() -> {                       // no frame arrived: give up cleanly
                if (!done[0]) {
                    done[0] = true;
                    finishShot();
                    toast("Screenshot failed");
                }
            }, 3000);
        } catch (Exception e) {
            finishShot();
            toast("Screenshot failed");
        }
    }

    private void finishShot() {
        try { if (vd != null && !recording) vd.setSurface(null); } catch (Exception ignored) { /* display gone */ }
        if (reader != null) {
            try { reader.close(); } catch (Exception ignored) { /* already closed */ }
            reader = null;
        }
        shotBusy = false;
        OverlayService.hideHud(false);
    }

    private static Bitmap toBitmap(Image img, int w, int h) {
        Image.Plane p = img.getPlanes()[0];
        ByteBuffer buf = p.getBuffer();
        int pixelStride = p.getPixelStride();
        int rowPadding = p.getRowStride() - pixelStride * w;
        Bitmap wide = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888);
        wide.copyPixelsFromBuffer(buf);
        if (wide.getWidth() == w) return wide;
        Bitmap cropped = Bitmap.createBitmap(wide, 0, 0, w, h);
        wide.recycle();
        return cropped;
    }

    private void saveShot(Bitmap bmp) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, "NEXUS_" + stamp() + ".png");
            v.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NEXUS");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IllegalStateException("no uri");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            v.clear();
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, v, null, null);
            toast("Screenshot saved · Pictures/NEXUS");
        } catch (Exception e) {
            toast("Could not save the screenshot");
        } finally {
            bmp.recycle();
        }
    }

    private static String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    // ------------------------------------------------------------------ screen recording

    private void startRecording() {
        if (projection == null || closing || recording) return;
        try {
            int[] s = screenSize();
            int targetH = 1080, fps = 60;
            String q = qualityString();
            if (q.contains("720p")) targetH = 720;
            else if (q.contains("1440p")) targetH = 1440;
            if (q.contains("30fps")) fps = 30;               // 120 fps is capped to 60: H.264 recorders rarely do more
            int shortSide = Math.min(s[0], s[1]);
            float scale = Math.min(1f, targetH / (float) shortSide);
            int w = even(Math.round(s[0] * scale)), h = even(Math.round(s[1] * scale));
            int bitrate = (int) Math.max(4_000_000L, Math.min(24_000_000L, (long) (w * (long) h * fps * 0.09)));

            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, "NEXUS_" + stamp() + ".mp4");
            v.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NEXUS");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            recUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            if (recUri == null) throw new IllegalStateException("no uri");
            recPfd = getContentResolver().openFileDescriptor(recUri, "w");

            MediaRecorder r = android.os.Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            r.setVideoSize(w, h);
            r.setVideoFrameRate(fps);
            r.setVideoEncodingBitRate(bitrate);
            r.setOutputFile(recPfd.getFileDescriptor());
            r.prepare();
            recorder = r;

            ensureDisplay(w, h, s[2]);
            vd.setSurface(r.getSurface());
            r.start();
            recStartMs = System.currentTimeMillis();
            recording = true;
            OverlayService.recordingChanged();
            toast("Recording started · tap the red chip to stop");
        } catch (Exception e) {
            releaseRecorder(true);
            recording = false;
            OverlayService.recordingChanged();
            toast("Could not start recording");
        }
    }

    private void stopRecording() {
        if (!recording) return;
        recording = false;
        long sec = Math.max(0, (System.currentTimeMillis() - recStartMs) / 1000);
        boolean failed = false;
        try { if (vd != null) vd.setSurface(null); } catch (Exception ignored) { /* display gone */ }
        try {
            recorder.stop();
        } catch (RuntimeException e) {
            failed = true;                                   // stopped too quickly: no frames were written
        }
        releaseRecorder(failed);
        OverlayService.recordingChanged();
        toast(failed ? "Recording was too short to save"
                : String.format(Locale.US, "Clip saved · %02d:%02d · Movies/NEXUS", sec / 60, sec % 60));
    }

    private void releaseRecorder(boolean deleteFile) {
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) { /* nothing */ }
            try { recorder.release(); } catch (Exception ignored) { /* nothing */ }
            recorder = null;
        }
        try { if (recPfd != null) recPfd.close(); } catch (Exception ignored) { /* nothing */ }
        recPfd = null;
        if (recUri != null) {
            try {
                if (deleteFile) {
                    getContentResolver().delete(recUri, null, null);
                } else {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(recUri, v, null, null);
                }
            } catch (Exception ignored) { /* nothing */ }
            recUri = null;
        }
    }

    private static int even(int v) { return v - (v % 2); }

    private String qualityString() {
        try {
            JSONObject rec = new JSONObject(Prefs.getState(this)).optJSONObject("rec");
            return rec == null ? "" : rec.optString("quality", "");
        } catch (Exception e) {
            return "";
        }
    }

    // ------------------------------------------------------------------ shutdown

    private void shutdown() {
        if (closing) return;
        closing = true;
        if (recording) stopRecording();
        finishShot();
        try { if (vd != null) vd.release(); } catch (Exception ignored) { /* nothing */ }
        vd = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { /* already stopped */ }
        projection = null;
        live = null;
        recording = false;
        OverlayService.recordingChanged();
        main.post(() -> {
            stopForeground(true);
            stopSelf();
        });
    }
}

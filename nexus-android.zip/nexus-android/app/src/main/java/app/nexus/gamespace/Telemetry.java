package app.nexus.gamespace;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.display.DisplayManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.view.Display;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Real numbers a normal Android app is allowed to read.
 * hz      = current display refresh rate (NOT the game's FPS: Android does not expose that without root)
 * cpu     = estimate from CPU clock speed (-1 if the phone hides it)
 * ram     = used memory in percent
 * temp    = battery temperature in degrees Celsius
 */
final class Telemetry {
    private Telemetry() { }

    private static long[] maxFreq = null;   // kHz per core, cached after the first read

    static JSONObject read(Context c) {
        JSONObject o = new JSONObject();
        try {
            int battery = 0;
            double temp = 0;
            boolean charging = false;
            Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                battery = scale > 0 ? Math.round(level * 100f / scale) : level;
                temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0;
                int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
            }
            o.put("battery", battery);
            o.put("temp", Math.round(temp * 10) / 10.0);
            o.put("charging", charging);
            o.put("ram", ram(c));
            o.put("cpu", cpuEstimate());
            o.put("hz", hz(c));
            o.put("net", net(c));
            o.put("time", new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
        } catch (Exception ignored) {
            // return whatever we managed to collect
        }
        return o;
    }

    private static int ram(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            if (mi.totalMem <= 0) return 0;
            return Math.round(100f * (mi.totalMem - mi.availMem) / mi.totalMem);
        } catch (Exception e) {
            return 0;
        }
    }

    private static int hz(Context c) {
        try {
            DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
            Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
            return d == null ? 60 : Math.round(d.getRefreshRate());
        } catch (Exception e) {
            return 60;
        }
    }

    private static String net(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return "offline";
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            if (nc == null) return "offline";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "wifi";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "mobile";
            return "other";
        } catch (Exception e) {
            return "wifi";
        }
    }

    private static int cpuEstimate() {
        try {
            if (maxFreq == null) {
                long[] m = new long[16];
                for (int i = 0; i < 16; i++) {
                    m[i] = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
                }
                maxFreq = m;
            }
            double sum = 0;
            int n = 0;
            for (int i = 0; i < 16; i++) {
                if (maxFreq[i] <= 0) continue;
                long cur = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq");
                if (cur <= 0) continue;
                sum += Math.min(1.0, (double) cur / (double) maxFreq[i]);
                n++;
            }
            return n == 0 ? -1 : (int) Math.round(100.0 * sum / n);
        } catch (Exception e) {
            return -1;
        }
    }

    private static long readLong(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            String s = r.readLine();
            return s == null ? -1 : Long.parseLong(s.trim());
        } catch (Exception e) {
            return -1;
        }
    }
}

package app.nexus.gamespace;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.provider.Settings;

import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** System switches the panel can change: brightness, media volume, Do Not Disturb. */
final class Controls {
    private Controls() { }

    // ---- Boost: ask Android to drop other apps' background processes (never touches the game) ----

    private static long availMb(ActivityManager am) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return mi.availMem / (1024 * 1024);
    }

    /** Runs on a background thread (called from the bridge). Returns JSON {ok, apps, freedMb}. */
    static String boost(Context c) {
        JSONObject o = new JSONObject();
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            PackageManager pm = c.getPackageManager();
            long before = availMb(am);
            Set<String> keep = new HashSet<String>();
            keep.add(c.getPackageName());
            keep.add("com.android.systemui");
            if (OverlayService.gamePkg != null) keep.add(OverlayService.gamePkg);
            ResolveInfo home = pm.resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0);
            if (home != null) keep.add(home.activityInfo.packageName);
            int n = 0;
            for (ResolveInfo ri : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
                String pkg = ri.activityInfo.packageName;
                if (keep.contains(pkg)) continue;
                am.killBackgroundProcesses(pkg);
                n++;
            }
            Thread.sleep(800);
            o.put("ok", true);
            o.put("apps", n);
            o.put("freedMb", Math.max(0, availMb(am) - before));
        } catch (Exception e) {
            try { o.put("ok", false); } catch (Exception ignored) { /* nothing */ }
        }
        return o.toString();
    }

    /** Android's own Wi-Fi / mobile data quick panel (apps may not switch them directly). */
    static void openInternetPanel(Context c) {
        try {
            c.startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                c.startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) {
                // no such page on this phone
            }
        }
    }

    // ---- brightness (needs the "Modify system settings" permission) ----

    static boolean setBrightness(Context c, int percent) {
        if (!Settings.System.canWrite(c)) return false;
        try {
            int v = Math.max(1, Math.min(255, Math.round(percent * 255f / 100f)));
            ContentResolver r = c.getContentResolver();
            Settings.System.putInt(r, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(r, Settings.System.SCREEN_BRIGHTNESS, v);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static int getBrightness(Context c) {
        try {
            int v = Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
            return Math.max(1, Math.min(100, Math.round(v * 100f / 255f)));
        } catch (Exception e) {
            return 50;
        }
    }

    // ---- media volume (no permission needed) ----

    static void setVolume(Context c, int percent) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            int v = Math.max(0, Math.min(max, Math.round(percent * max / 100f)));
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
        } catch (Exception ignored) {
            // some phones block this while a call is active
        }
    }

    static int getVolume(Context c) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            return max <= 0 ? 50 : Math.round(100f * am.getStreamVolume(AudioManager.STREAM_MUSIC) / max);
        } catch (Exception e) {
            return 50;
        }
    }

    // ---- Do Not Disturb = "Block Notifications" (needs Do Not Disturb access) ----

    /** True only while NEXUS itself switched Do Not Disturb on and it is still on. */
    static boolean dndOn(Context c) {
        if (!Prefs.getBool(c, "dndOn", false) || !Perms.dnd(c)) return false;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
    }

    static boolean setDnd(Context c, boolean on) {
        if (!Perms.dnd(c)) return false;
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (on) {
                if (!Prefs.getBool(c, "dndOn", false)) {
                    Prefs.putInt(c, "dndPrev", nm.getCurrentInterruptionFilter());
                    Prefs.putBool(c, "dndOn", true);
                }
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            } else {
                restoreDnd(c);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Puts Do Not Disturb back the way it was before NEXUS changed it. */
    static void restoreDnd(Context c) {
        try {
            if (!Prefs.getBool(c, "dndOn", false)) return;
            Prefs.putBool(c, "dndOn", false);
            if (!Perms.dnd(c)) return;
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            int prev = Prefs.getInt(c, "dndPrev", NotificationManager.INTERRUPTION_FILTER_ALL);
            if (prev == NotificationManager.INTERRUPTION_FILTER_UNKNOWN) prev = NotificationManager.INTERRUPTION_FILTER_ALL;
            nm.setInterruptionFilter(prev);
        } catch (Exception ignored) {
            // nothing else we can do
        }
    }
}

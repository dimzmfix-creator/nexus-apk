package app.nexus.gamespace;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

/** Invisible activity whose only job is to show Android's "Start recording or casting?" dialog. */
public class ProjectionActivity extends Activity {

    private static final int REQ = 7;
    private String what = "shot";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String w = getIntent().getStringExtra("what");
        if (w != null) what = w;
        if (savedInstanceState != null) return;   // re-created after rotation: the dialog is already showing
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ);
        } catch (Exception e) {
            Toast.makeText(this, "Screen capture is not available on this device", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ) {
            if (resultCode == RESULT_OK && data != null) {
                CaptureService.begin(this, resultCode, data, what);
            } else {
                Toast.makeText(this, "Screen capture was not allowed", Toast.LENGTH_SHORT).show();
            }
        }
        finish();
    }
}

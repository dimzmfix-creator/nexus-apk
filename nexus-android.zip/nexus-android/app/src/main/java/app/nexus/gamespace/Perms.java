package app.nexus.gamespace;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import org.json.JSONObject;

/** The special permissions NEXUS needs. Android makes the user grant them in system Settings pages. */
final class Perms {
    private Perms() { }

    static boolean overlay(Context c) { return Settings.canDrawOverlays(c); }

    static boolean writeSettings(Context c) { return Settings.System.canWrite(c); }

    static boolean dnd(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm != null && nm.isNotificationPolicyAccessGranted();
    }

    static boolean notifications(Context c) {
        return Build.VERSION.SDK_INT < 33
                || c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
    }

    static JSONObject status(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("overlay", overlay(c));
            o.put("writeSettings", writeSettings(c));
            o.put("dnd", dnd(c));
            o.put("notifications", notifications(c));
        } catch (Exception ignored) {
            // never happens for plain keys
        }
        return o;
    }

    /** Opens the system Settings page where the user can grant {@code key}. */
    static void openSettings(Context c, String key) {
        String pkg = c.getPackageName();
        Intent i;
        if ("overlay".equals(key)) {
            i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + pkg));
        } else if ("writeSettings".equals(key)) {
            i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + pkg));
        } else if ("dnd".equals(key)) {
            i = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
        } else {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
        } catch (Exception e) {
            // a few phones do not have that settings page
        }
    }
}

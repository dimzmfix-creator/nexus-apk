package app.nexus.gamespace;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Lists the apps you can launch and flags the ones that look like games. */
final class Apps {
    private Apps() { }

    private static final Set<String> KNOWN = new HashSet<String>(Arrays.asList(
            "com.mobile.legends", "com.tencent.ig", "com.pubg.imobile", "com.miHoYo.GenshinImpact",
            "com.activision.callofduty.shooter", "com.HoYoverse.hkrpgoversea", "com.riotgames.league.wildrift",
            "com.dts.freefireth", "com.dts.freefiremax", "com.supercell.clashofclans", "com.roblox.client",
            "com.mojang.minecraftpe", "com.garena.game.codm", "com.proximabeta.mf.uamo"));

    static String listJson(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        List<JSONObject> out = new ArrayList<JSONObject>();
        Set<String> seen = new HashSet<String>();
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(c.getPackageName()) || !seen.add(pkg)) continue;
            try {
                JSONObject o = new JSONObject();
                o.put("pkg", pkg);
                o.put("name", String.valueOf(ri.loadLabel(pm)));
                o.put("game", isGame(ri.activityInfo.applicationInfo));
                out.add(o);
            } catch (Exception ignored) {
                // skip this app
            }
        }
        Collections.sort(out, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject a, JSONObject b) {
                boolean ga = a.optBoolean("game");
                boolean gb = b.optBoolean("game");
                if (ga != gb) return ga ? -1 : 1;
                return a.optString("name").compareToIgnoreCase(b.optString("name"));
            }
        });
        JSONArray arr = new JSONArray();
        for (JSONObject o : out) arr.put(o);
        return arr.toString();
    }

    @SuppressWarnings("deprecation")
    private static boolean isGame(ApplicationInfo ai) {
        if (KNOWN.contains(ai.packageName)) return true;
        if (ai.category == ApplicationInfo.CATEGORY_GAME) return true;
        return (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
    }

    static String label(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    /** App icon as a data: URL the web UI can use directly in an <img>. */
    static String icon(Context c, String pkg) {
        try {
            Drawable d = c.getPackageManager().getApplicationIcon(pkg);
            int s = 96;
            Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            d.setBounds(0, 0, s, s);
            d.draw(cv);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.PNG, 100, bo);
            return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }
}

# Perubahan v1.0 → v1.1 (format Cari/Ganti)

Cara pakai: di file yang disebut, cari teks di blok **Cari**, lalu ganti dengan teks di blok **Ganti**.
Catatan: `app/src/main/assets/index.html` berubah besar (tampilan web), jadi cukup **ganti seluruh file** dengan yang ada di zip.
Cara termudah tetap mengunggah zip proyek yang baru.


## `README.md`

**Perubahan 1**

Cari:
```
screenshot, rekam layar (video saja, tanpa suara), kecerahan, volume media, Block Notifications (Jangan Ganggu mode prioritas), daftar game asli + peluncur.

**Hanya pratinjau (ditandai "Preview only"):** Bypass Charging, AirTriggers, X Sense AI, Macro, Refresh Rate sistem, Network Switch —
butuh root/akses hardware yang tidak diberikan Android ke aplikasi biasa.

```
Ganti:
```
screenshot, rekam layar (video saja, tanpa suara), kecerahan, volume media, Block Notifications (Jangan Ganggu mode prioritas), daftar game asli + peluncur.

**Baru di v1.1:** tombol **Boost** (menutup proses latar belakang aplikasi lain, tidak menyentuh game), **Network Switch** (membuka panel internet bawaan Android),
setelan **Pegangan Panel** (sisi kiri/kanan, posisi, ukuran, ketuk atau geser), crosshair baru (bentuk T, warna, ketebalan), kartu suhu berubah merah saat HP panas (≥44°C),
ringkasan sesi setelah keluar Game Mode, dan panel yang dimuat lebih awal agar terbuka cepat.
NEXUS **tidak mengubah file atau isi game apa pun**, jadi tidak ada risiko seperti mod.

**Hanya pratinjau (ditandai "Preview only"):** Bypass Charging, AirTriggers, X Sense AI, Macro, Refresh Rate sistem —
butuh root/akses hardware yang tidak diberikan Android ke aplikasi biasa.

```


## `app/build.gradle`

**Perubahan 1**

Cari:
```
        minSdk 29
        targetSdk 34
        versionCode 1
        versionName '1.0.0'
    }

```
Ganti:
```
        minSdk 29
        targetSdk 34
        versionCode 2
        versionName '1.1.0'
    }

```


## `app/src/main/AndroidManifest.xml`

**Perubahan 1**

Cari:
```
    <!-- Draw the HUD, crosshair and panel on top of games -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <!-- Keep the overlay / screen capture alive while a game is in front -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
```
Ganti:
```
    <!-- Draw the HUD, crosshair and panel on top of games -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.KILL_BACKGROUND_PROCESSES" />
    <!-- Keep the overlay / screen capture alive while a game is in front -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
```


## `app/src/main/assets/index.html`
Ganti seluruh file (lihat zip).


## `app/src/main/java/app/nexus/gamespace/Bridge.java`

**Perubahan 1**

Cari:
```

    @JavascriptInterface
    public void capture() {
        CaptureService.screenshot(c);
```
Ganti:
```

    @JavascriptInterface
    public String boost() {
        return Controls.boost(c);
    }

    @JavascriptInterface
    public void openInternetPanel() {
        if (host != null) host.closePanel();
        Controls.openInternetPanel(c);
    }

    @JavascriptInterface
    public void capture() {
        CaptureService.screenshot(c);
```


## `app/src/main/java/app/nexus/gamespace/Controls.java`

**Perubahan 1**

Cari:
```
package app.nexus.gamespace;

import android.app.NotificationManager;
import android.content.ContentResolver;
```
Ganti:
```
package app.nexus.gamespace;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.ContentResolver;
```

**Perubahan 2**

Cari:
```
import android.content.ContentResolver;
import android.content.Context;
import android.media.AudioManager;
import android.provider.Settings;
```
Ganti:
```
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.provider.Settings;
```

**Perubahan 3**

Cari:
```
import android.media.AudioManager;
import android.provider.Settings;

/** System switches the panel can change: brightness, media volume, Do Not Disturb. */
```
Ganti:
```
import android.media.AudioManager;
import android.provider.Settings;

import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** System switches the panel can change: brightness, media volume, Do Not Disturb. */
```

**Perubahan 4**

Cari:
```
final class Controls {
    private Controls() { }

    // ---- brightness (needs the "Modify system settings" permission) ----
```
Ganti:
```
final class Controls {
    private Controls() { }

    // ---- Boost: ask Android to drop other apps' background processes (never touches the game) ----

    private static long availMb(ActivityManager am) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return mi.availMem / (1024 * 1024);
    }

    /** Runs on a background thread (called from the bridge). Returns JSON {ok, apps, freedMb}. */
    static String boost(Context c) {
        JSONObject o = new JSONObject();
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            PackageManager pm = c.getPackageManager();
            long before = availMb(am);
            Set<String> keep = new HashSet<String>();
            keep.add(c.getPackageName());
            keep.add("com.android.systemui");
            if (OverlayService.gamePkg != null) keep.add(OverlayService.gamePkg);
            ResolveInfo home = pm.resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0);
            if (home != null) keep.add(home.activityInfo.packageName);
            int n = 0;
            for (ResolveInfo ri : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
                String pkg = ri.activityInfo.packageName;
                if (keep.contains(pkg)) continue;
                am.killBackgroundProcesses(pkg);
                n++;
            }
            Thread.sleep(800);
            o.put("ok", true);
            o.put("apps", n);
            o.put("freedMb", Math.max(0, availMb(am) - before));
        } catch (Exception e) {
            try { o.put("ok", false); } catch (Exception ignored) { /* nothing */ }
        }
        return o.toString();
    }

    /** Android's own Wi-Fi / mobile data quick panel (apps may not switch them directly). */
    static void openInternetPanel(Context c) {
        try {
            c.startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                c.startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) {
                // no such page on this phone
            }
        }
    }

    // ---- brightness (needs the "Modify system settings" permission) ----
```


## `app/src/main/java/app/nexus/gamespace/MainActivity.java`

**Perubahan 1**

Cari:
```
        runOnUiThread(() -> {
            try {
                OverlayService.start(MainActivity.this);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
```
Ganti:
```
        runOnUiThread(() -> {
            try {
                OverlayService.gamePkg = pkg;
                OverlayService.start(MainActivity.this);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
```


## `app/src/main/java/app/nexus/gamespace/OverlayService.java`

**Perubahan 1**

Cari:
```

    static OverlayService instance;

    static final String ACTION_START = "app.nexus.gamespace.START";
```
Ganti:
```

    static OverlayService instance;
    static volatile String gamePkg;   // the game NEXUS launched (Boost never touches it)

    static final String ACTION_START = "app.nexus.gamespace.START";
```

**Perubahan 2**

Cari:
```
    private boolean running = false;

    static void start(Context c) {
        Intent i = new Intent(c, OverlayService.class).setAction(ACTION_START);
```
Ganti:
```
    private boolean running = false;

    // numbers for the end-of-session summary
    private long sessStart = 0;
    private int sessBat0 = -1, sessBat1 = -1, sessN = 0;
    private double sessTempMax = 0, sessRamSum = 0;

    static void start(Context c) {
        Intent i = new Intent(c, OverlayService.class).setAction(ACTION_START);
```

**Perubahan 3**

Cari:
```
            }
            running = true;
            views.show();
            views.applyState(parse(Prefs.getState(this)));
```
Ganti:
```
            }
            running = true;
            sessStart = System.currentTimeMillis();
            sessBat0 = sessBat1 = -1;
            sessN = 0;
            sessTempMax = 0;
            sessRamSum = 0;
            views.show();
            views.applyState(parse(Prefs.getState(this)));
```

**Perubahan 4**

Cari:
```
            syncRecording();
            main.post(tick);
        }
        if (ACTION_PANEL.equals(action)) openPanel();
```
Ganti:
```
            syncRecording();
            main.post(tick);
            main.postDelayed(() -> { if (running && panel == null) createPanel(); }, 4000);   // warm up the panel so it opens instantly
        }
        if (ACTION_PANEL.equals(action)) openPanel();
```

**Perubahan 5**

Cari:
```
                return;
            }
            views.updateTelemetry(Telemetry.read(OverlayService.this));
            views.setRecording(CaptureService.isRecording(), CaptureService.recStart());
            main.postDelayed(this, 1000);
```
Ganti:
```
                return;
            }
            JSONObject t = Telemetry.read(OverlayService.this);
            views.updateTelemetry(t);
            if (sessBat0 < 0) sessBat0 = t.optInt("battery", -1);
            sessBat1 = t.optInt("battery", sessBat1);
            sessTempMax = Math.max(sessTempMax, t.optDouble("temp", 0));
            sessRamSum += t.optInt("ram", 0);
            sessN++;
            views.setRecording(CaptureService.isRecording(), CaptureService.recStart());
            main.postDelayed(this, 1000);
```

**Perubahan 6**

Cari:
```

    private void stopOverlay() {
        running = false;
        main.removeCallbacksAndMessages(null);
```
Ganti:
```

    private void stopOverlay() {
        if (running) postSessionSummary();
        running = false;
        main.removeCallbacksAndMessages(null);
```

**Perubahan 7**

Cari:
```
        stopForeground(true);
        stopSelf();
    }

```
Ganti:
```
        stopForeground(true);
        stopSelf();
    }

    /** One quiet notification when you leave Game Mode: how long, how hot, how much battery. */
    private void postSessionSummary() {
        long min = (System.currentTimeMillis() - sessStart) / 60000;
        if (min < 1 || sessN == 0) return;
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("nexus_report", "NEXUS session summary", NotificationManager.IMPORTANCE_LOW));
            String text = min + " min · max " + Math.round(sessTempMax) + "°C · battery " + sessBat0 + "% → " + sessBat1 + "% · RAM avg " + Math.round(sessRamSum / sessN) + "%";
            Notification n = new Notification.Builder(this, "nexus_report")
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("Game session summary")
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setAutoCancel(true)
                    .build();
            nm.notify(43, n);
        } catch (Exception ignored) {
            // notifications are blocked: skip the summary
        }
    }

```

**Perubahan 8**

Cari:
```
        final Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) return false;
        main.post(() -> {
            try {
```
Ganti:
```
        final Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) return false;
        gamePkg = pkg;
        main.post(() -> {
            try {
```

**Perubahan 9**

Cari:
```
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        panelLp = new WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
```
Ganti:
```
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                // the page boots with the panel "open"; if it was only pre-loaded, tell it to rest closed
                if (!panelOpen) js("window.__nativeEvent&&window.__nativeEvent('{\"panelOpen\":false,\"subPanelOpen\":false}')");
            }
        });
        panelLp = new WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
```


## `app/src/main/java/app/nexus/gamespace/OverlayViews.java`

**Perubahan 1**

Cari:
```
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
```
Ganti:
```
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
```

**Perubahan 2**

Cari:
```
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
```
Ganti:
```
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
```

**Perubahan 3**

Cari:
```

import org.json.JSONObject;

/**
```
Ganti:
```

import org.json.JSONObject;

import java.util.Collections;

/**
```

**Perubahan 4**

Cari:
```
    private boolean shown = false;
    private boolean hidden = false;

    // latest data, so a rebuild (rotation) can redraw immediately
```
Ganti:
```
    private boolean shown = false;
    private boolean hidden = false;
    private boolean hot = false;
    private String hSide = "right", hMode = "tap";
    private int hPos = 45, hSize = 100;

    // latest data, so a rebuild (rotation) can redraw immediately
```

**Perubahan 5**

Cari:
```

    private void build() {
        cpuT = label(); ramT = label();
        left = card(cpuT, ramT);
```
Ganti:
```

    private void build() {
        hot = false;
        cpuT = label(); ramT = label();
        left = card(cpuT, ramT);
```

**Perubahan 6**

Cari:
```

        edge = new View(ctx);
        edge.setBackground(round(0xCC7B5CFF, 0, 6));
        edge.setOnTouchListener(new EdgeTouch());

```
Ganti:
```

        edge = new View(ctx);
        edge.setBackground(handleBg());
        edge.setOnTouchListener(new EdgeTouch());

```

**Perubahan 7**

Cari:
```
        add(cross, Gravity.CENTER, 0, 0, false);
        add(recChip, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, px(64), true);
        addSized(edge, Gravity.END | Gravity.CENTER_VERTICAL, 0, -px(70), px(14), px(88), true);
    }

```
Ganti:
```
        add(cross, Gravity.CENTER, 0, 0, false);
        add(recChip, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, px(64), true);
        addSized(edge, edgeGravity(), 0, edgeY(), px(14f * hSize / 100f), px(88f * hSize / 100f), true);
        edge.post(this::updateExclusion);
    }

```

**Perubahan 8**

Cari:
```
    void applyState(JSONObject s) {
        state = s == null ? new JSONObject() : s;
        positionAll();
        refresh();
```
Ganti:
```
    void applyState(JSONObject s) {
        state = s == null ? new JSONObject() : s;
        JSONObject hd = state.optJSONObject("handle");
        if (hd != null) {
            hSide = hd.optString("side", "right");
            hPos = hd.optInt("pos", 45);
            hSize = hd.optInt("size", 100);
            hMode = hd.optString("mode", "tap");
        }
        positionAll();
        refresh();
```

**Perubahan 9**

Cari:
```
        String temp = fahrenheit ? Math.round(c * 9 / 5 + 32) + "°F" : Math.round(c) + "°C";
        tempNetT.setText(temp + "  ·  " + netName(tele.optString("net", "wifi")));
        hzT.setVisibility(vFps ? View.VISIBLE : View.GONE);
        tempNetT.setVisibility(vTemp || vNet ? View.VISIBLE : View.GONE);
```
Ganti:
```
        String temp = fahrenheit ? Math.round(c * 9 / 5 + 32) + "°F" : Math.round(c) + "°C";
        tempNetT.setText(temp + "  ·  " + netName(tele.optString("net", "wifi")));
        boolean nowHot = c >= 44;
        if (nowHot != hot) {                      // card turns red when the phone gets hot
            hot = nowHot;
            center.setBackground(round(hot ? 0xE6551018 : 0xE60F0F18, hot ? 0xAAFF3B6B : 0x33FFFFFF, 12));
        }
        hzT.setVisibility(vFps ? View.VISIBLE : View.GONE);
        tempNetT.setVisibility(vTemp || vNet ? View.VISIBLE : View.GONE);
```

**Perubahan 10**

Cari:
```
        // crosshair
        cross.setVisibility(crossOn ? View.VISIBLE : View.GONE);
        if (ch != null) cross.configure(ch.optString("style", "cross"), ch.optInt("size", 100), ch.optInt("opacity", 90));

        // recording chip
```
Ganti:
```
        // crosshair
        cross.setVisibility(crossOn ? View.VISIBLE : View.GONE);
        JSONObject cc = ch == null ? new JSONObject() : ch;
        cross.configure(cc.optString("style", "cross"), cc.optInt("size", 100), cc.optInt("opacity", 90),
                cc.optString("color", "#FF3B6B"), cc.optInt("thick", 2));

        // recording chip
```

**Perubahan 11**

Cari:
```
        move(center, Gravity.TOP | Gravity.CENTER_HORIZONTAL, off(pos, "c", "x"), Math.max(0, margin + off(pos, "c", "y")));
        move(right, Gravity.TOP | Gravity.END, margin - off(pos, "r", "x"), Math.max(0, margin + off(pos, "r", "y")));
    }

```
Ganti:
```
        move(center, Gravity.TOP | Gravity.CENTER_HORIZONTAL, off(pos, "c", "x"), Math.max(0, margin + off(pos, "c", "y")));
        move(right, Gravity.TOP | Gravity.END, margin - off(pos, "r", "x"), Math.max(0, margin + off(pos, "r", "y")));
        placeEdge();
    }

    // ---- edge handle: side, height, size; kept out of the system back-gesture zone ----

    private int edgeGravity() { return ("left".equals(hSide) ? Gravity.START : Gravity.END) | Gravity.CENTER_VERTICAL; }

    private int edgeY() {
        int h = Resources.getSystem().getDisplayMetrics().heightPixels;
        return Math.round((hPos - 50) / 100f * h);
    }

    private GradientDrawable handleBg() {
        GradientDrawable g = round(0xCC7B5CFF, 0, 0);
        float r = px(7);
        g.setCornerRadii("left".equals(hSide) ? new float[]{0, 0, r, r, r, r, 0, 0} : new float[]{r, r, 0, 0, 0, 0, r, r});
        return g;
    }

    private void placeEdge() {
        if (edge == null) return;
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) edge.getLayoutParams();
            if (lp == null) return;
            lp.gravity = edgeGravity();
            lp.x = 0;
            lp.y = edgeY();
            lp.width = px(14f * hSize / 100f);
            lp.height = px(88f * hSize / 100f);
            edge.setBackground(handleBg());
            wm.updateViewLayout(edge, lp);
            edge.post(this::updateExclusion);
        } catch (Exception ignored) {
            // not attached right now
        }
    }

    private void updateExclusion() {
        if (edge == null) return;
        try {
            edge.setSystemGestureExclusionRects(Collections.singletonList(new Rect(0, 0, edge.getWidth(), edge.getHeight())));
        } catch (Exception ignored) {
            // older/odd ROMs: harmless
        }
    }

```

**Perubahan 12**

Cari:
```
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawX() - downX) > px(24)) {   // swipe towards the middle of the screen
                        onEdgeTap.run();
                        downX = Float.MAX_VALUE;
```
Ganti:
```
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if ("swipe".equals(hMode) && Math.abs(e.getRawX() - downX) > px(24)) {   // swipe towards the middle of the screen
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                        onEdgeTap.run();
                        downX = Float.MAX_VALUE;
```

**Perubahan 13**

Cari:
```
                    return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(e.getRawX() - downX) < px(10) && Math.abs(e.getRawY() - downY) < px(10)) onEdgeTap.run();
                    return true;
                default:
```
Ganti:
```
                    return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(e.getRawX() - downX) < px(10) && Math.abs(e.getRawY() - downY) < px(10)) {
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                        onEdgeTap.run();
                    }
                    return true;
                default:
```

**Perubahan 14**

Cari:
```
        private int size = 100;
        private int opacity = 90;

        CrosshairView(Context c) {
```
Ganti:
```
        private int size = 100;
        private int opacity = 90;
        private int color = ACCENT;
        private int thick = 2;

        CrosshairView(Context c) {
```

**Perubahan 15**

Cari:
```
        }

        void configure(String st, int sz, int op) {
            if (!st.equals(style) || sz != size || op != opacity) {
                style = st;
                size = sz;
```
Ganti:
```
        }

        void configure(String st, int sz, int op, String col, int th) {
            int c = ACCENT;
            try { c = Color.parseColor(col); } catch (Exception ignored) { /* keep default colour */ }
            if (!st.equals(style) || sz != size || op != opacity || c != color || th != thick) {
                style = st;
                size = sz;
```

**Perubahan 16**

Cari:
```
                size = sz;
                opacity = op;
                requestLayout();
                invalidate();
```
Ganti:
```
                size = sz;
                opacity = op;
                color = c;
                thick = th;
                requestLayout();
                invalidate();
```

**Perubahan 17**

Cari:
```
        @Override
        protected void onMeasure(int w, int h) {
            int d = (int) Math.ceil(half() * 2 + px(6));
            setMeasuredDimension(d, d);
        }
```
Ganti:
```
        @Override
        protected void onMeasure(int w, int h) {
            int d = (int) Math.ceil(half() * 2 + px(8));
            setMeasuredDimension(d, d);
        }
```

**Perubahan 18**

Cari:
```
        protected void onDraw(Canvas cv) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = half();
            p.setColor(ACCENT);
            p.setAlpha(Math.round(255 * Math.max(10, Math.min(100, opacity)) / 100f));
            p.setStrokeWidth(px(2));
```
Ganti:
```
        protected void onDraw(Canvas cv) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = half();
            p.setColor(color);
            p.setAlpha(Math.round(255 * Math.max(10, Math.min(100, opacity)) / 100f));
            p.setStrokeWidth(px(2));
```

**Perubahan 19**

Cari:
```
            p.setColor(ACCENT);
            p.setAlpha(Math.round(255 * Math.max(10, Math.min(100, opacity)) / 100f));
            p.setStrokeWidth(px(2));
            if ("dot".equals(style)) {
                p.setStyle(Paint.Style.FILL);
```
Ganti:
```
            p.setColor(ACCENT);
            p.setAlpha(Math.round(255 * Math.max(10, Math.min(100, opacity)) / 100f));
            p.setStrokeWidth(px(Math.max(1, Math.min(6, thick))));
            if ("dot".equals(style)) {
                p.setStyle(Paint.Style.FILL);
```

**Perubahan 20**

Cari:
```
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, px(1.5f), p);
            } else {
                p.setStyle(Paint.Style.STROKE);
```
Ganti:
```
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, px(1.5f), p);
            } else if ("tee".equals(style)) {
                p.setStyle(Paint.Style.STROKE);
                float gap = r * 0.28f;
                cv.drawLine(cx - r, cy, cx - gap, cy, p);
                cv.drawLine(cx + gap, cy, cx + r, cy, p);
                cv.drawLine(cx, cy + gap, cx, cy + r, p);
            } else {
                p.setStyle(Paint.Style.STROKE);
```

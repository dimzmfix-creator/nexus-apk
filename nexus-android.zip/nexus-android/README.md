# NEXUS Game Space — proyek APK Android

Aplikasi ini = tampilan web NEXUS (di `app/src/main/assets/index.html`) yang dibungkus app Android,
ditambah kode native (Java) supaya fiturnya benar-benar bekerja di atas game.

> **Status jujur:** kode native ditulis tanpa bisa dikompilasi/diuji di perangkat asli (lingkungan pembuatnya tidak punya Android SDK).
> Kemungkinan ada error build kecil. Kalau build gagal, kirim log error-nya, dan akan diperbaiki.

## Cara membuat APK (tanpa install apa pun, cukup browser HP/PC)

1. Buat akun di https://github.com lalu buat repository baru (misal `nexus-apk`, Public atau Private).
2. **Jika memakai PC:** ekstrak zip ini, lalu upload semua isinya (termasuk folder `.github`) lewat *Add file → Upload files*.
   **Jika memakai HP:** upload file `nexus-android.zip` apa adanya ke repo (*Add file → Upload files*), lalu buat file
   `.github/workflows/build-apk.yml` lewat *Add file → Create new file* (ketik path itu di kolom nama, tempel isi file `build-apk.yml` yang dikirim terpisah).
3. Buka tab **Actions**. Workflow "Build APK" jalan otomatis (kalau tidak: pilih Build APK → *Run workflow*). Tunggu ±5–8 menit sampai centang hijau.
4. Klik run yang berhasil → bagian **Artifacts** → unduh `NEXUS-GameSpace-APK` (berupa zip berisi `app-debug.apk`).
5. Ekstrak, kirim `app-debug.apk` ke HP, buka, izinkan "Install dari sumber tidak dikenal", lalu install.

## Izin yang perlu diberikan (Settings → Permissions di dalam app)

| Izin | Untuk apa |
|---|---|
| Tampil di atas aplikasi lain | HUD, crosshair, panel di atas game (wajib) |
| Ubah pengaturan sistem | Slider kecerahan |
| Akses Jangan Ganggu | Tombol Block Notifications |
| Notifikasi | Menampilkan notifikasi "Game Mode aktif" |

Screenshot/rekam layar meminta izin sistem sekali per sesi: pilih **"Seluruh layar"**.

## Cara pakai

1. Buka NEXUS → ketuk game di daftar (daftar diambil dari app yang terpasang; atur game mana yang tampil di Settings).
2. Game terbuka, HUD & crosshair muncul. Geser dari tepi kanan layar (pegangan kecil) atau ketuk **Open panel** di notifikasi untuk membuka panel.
3. Screenshot tersimpan di `Pictures/NEXUS`, rekaman di `Movies/NEXUS`. Chip merah = sedang merekam, ketuk untuk berhenti.
4. Keluar: tombol Exit di panel atau **Stop** di notifikasi (mengembalikan mode Jangan Ganggu seperti semula).

## Yang benar-benar berfungsi vs. hanya tampilan

**Berfungsi:** overlay HUD (refresh rate layar, estimasi CPU, RAM, suhu baterai, jaringan, jam, baterai), crosshair (3 gaya, ukuran, opacity),
screenshot, rekam layar (video saja, tanpa suara), kecerahan, volume media, Block Notifications (Jangan Ganggu mode prioritas), daftar game asli + peluncur.

**Baru di v1.1:** tombol **Boost** (menutup proses latar belakang aplikasi lain, tidak menyentuh game), **Network Switch** (membuka panel internet bawaan Android),
setelan **Pegangan Panel** (sisi kiri/kanan, posisi, ukuran, ketuk atau geser), crosshair baru (bentuk T, warna, ketebalan), kartu suhu berubah merah saat HP panas (≥44°C),
ringkasan sesi setelah keluar Game Mode, dan panel yang dimuat lebih awal agar terbuka cepat.
NEXUS **tidak mengubah file atau isi game apa pun**, jadi tidak ada risiko seperti mod.

**Hanya pratinjau (ditandai "Preview only"):** Bypass Charging, AirTriggers, X Sense AI, Macro, Refresh Rate sistem —
butuh root/akses hardware yang tidak diberikan Android ke aplikasi biasa.

**Batasan:** Android tidak memberi FPS/CPU/GPU game lain ke aplikasi biasa, jadi HUD menampilkan Hz layar & estimasi.
HUD tidak bisa digeser saat main (agar tidak menghalangi sentuhan game). Rekaman maksimal 60 fps.

## Jika build gagal

Buka run yang gagal di Actions → klik step **Build debug APK** → salin ±40 baris terakhir yang memuat kata `error`, kirim ke pembuat.
